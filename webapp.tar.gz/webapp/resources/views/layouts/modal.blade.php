<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                @yield('modal-head')<h4 class="modal-title">Modal Header</h4>
            </div>
            <div class="modal-body">
                @yield('modal-bod')<p>Some text in the modal.</p>
            </div>
            <div class="modal-footer">
                @yield('modal-foot')<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

   <div class="card card-success" id="orderModal">
        <div class="card-header">
            <div class="header-block">
                <p class="title"> Success card </p>
            </div>
        </div>
        <div class="card-block">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tincidunt est vitae ultrices accumsan. Aliquam ornare lacus adipiscing, posuere lectus et, fringilla augue.</p>
        </div>
        <div class="card-footer"> Card Footer </div>
    </div>

    @yield('modal')
