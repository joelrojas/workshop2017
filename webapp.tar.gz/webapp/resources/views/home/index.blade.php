<!-- /**
 * Created by PhpStorm.
 * User: joel
 * Date: 29-09-17
 * Time: 12:36 AM
 */-->
@extends('layouts.app')

@section('menu_dashboard', 'open active')
@section('title', 'Inicio')
@section('title-description', 'Página Principal')
@section('css')

@section('content')

@endsection

@section('js')
    <script src="js/vendor.js"></script>
    <script src="js/app-template.js"></script>
@endsection