<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kardex extends Model
{
    //
}
