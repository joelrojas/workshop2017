<?php $__env->startSection('menu_kardex', 'open active'); ?>
<?php $__env->startSection('title', 'Kardex de inventarios'); ?>
<?php $__env->startSection('title-description', 'Inventario relacionado a los proveedores'); ?>

<?php $__env->startSection('content'); ?>

    <section class="section">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <table id="orderTable">
                        <thead>
                        <tr>
                            <td>Producto</td>
                            <td>Precio Unitario</td>
                            <td>Proveedor</td>
                            <td>Opciones</td>
                        </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-head'); ?>
    <h4 class="modal-title">Comprar producto</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-bod'); ?>
    <p>pfffffff</p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-foot'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="js/vendor.js"></script>
    <script src="js/app-template.js"></script>
    <script src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>