<?php $__env->startSection('menu_kardex', 'open active'); ?>
<?php $__env->startSection('title', 'Kardex de inventarios'); ?>
<?php $__env->startSection('title-description', 'Inventario relacionado a los proveedores'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <table id="mainTable">
                        <thead>
                        <tr>
                            <td>Fecha</td>
                            <td>Detalle</td>
                            <td>Valor unitario</td>
                            <td>Cantidad</td>
                            <td>Valores</td>
                            <td>Cantidad</td>
                            <td>Valores</td>
                            <td>Cantidad</td>
                            <td>Valores</td>
                        </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>