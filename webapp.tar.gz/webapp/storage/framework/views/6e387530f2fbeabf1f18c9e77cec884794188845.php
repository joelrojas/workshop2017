<!-- /**
 * Created by PhpStorm.
 * User: joel
 * Date: 29-09-17
 * Time: 12:36 AM
 */-->


<?php $__env->startSection('menu_dashboard', 'open active'); ?>
<?php $__env->startSection('title', 'Inicio'); ?>
<?php $__env->startSection('title-description', 'Página Principal'); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="js/vendor.js"></script>
    <script src="js/app-template.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>