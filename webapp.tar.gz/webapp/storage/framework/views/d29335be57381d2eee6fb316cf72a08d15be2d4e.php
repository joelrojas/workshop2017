<?php $__env->startSection('menu_catalog', 'open active'); ?>
<?php $__env->startSection('title', 'Listado de Catalogos'); ?>
<?php $__env->startSection('title-description', 'Administración de los catalogos del sistema'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				<table id="mainTable">
					<thead>
					<tr>
						<td>Acciones</td>
						<td>Código</td>
						<td>Descripción</td>
					</tr>
					</thead>
					<tbody>
					</tbody>
				</table>	
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script src="js/vendor.js"></script>
	<script src="js/app-template.js"></script>
	<script src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
	<script src="js/main.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>